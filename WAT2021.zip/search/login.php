<?php
include 'connection.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    // echo $username . $password;

    $sql = "select * from user WHERE Username='$username'  && Password='$password' ";
    $qry = mysqli_query($connection, $sql);
    $count = mysqli_num_rows($qry);
    if ($count == 1) {
        session_start();
        $_SESSION['uname'] = $username;
        header("Location: search.php");
    } else {
        echo "User not found!";
    }
}
?>

<form method="POST" action="search.php">
    <fieldset>
        <legend>Login</legend>
        <label>Username:</label>
        <input type="text" name="username">

        <label>Password:</label>
        <input type="password" name="password">
        <input type="submit" name="login" value="Login" />
    </fieldset>
</form>
