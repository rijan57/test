<?php

//Set up the database access credentials
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'wat2021';
$connection = mysqli_connect($hostname, $username, $password, $database) or
exit("Unable to connect to database!");
