<?php
session_start();

if (isset($_GET['search'])) {
    $category = $_GET['category'];
    $search = $_GET['search-text'];
    $sortvalue = $_GET['sort'];

    if ($category == "All") {
        if ($sortvalue == 1) {
            $sql = "SELECT * from products WHERE Name LIKE '%$search%' ORDER BY Name";
        } elseif ($sortvalue == 2) {
            $sql = "SELECT * from products WHERE Name LIKE '%$search%' ORDER BY Price ASC";
        } else {
            $sql = "SELECT * from products WHERE Name LIKE '%$search%' ORDER BY Price DESC";
        }
    } else {
        if ($sortvalue == 1) {
            $sql = "SELECT * from products WHERE Category='$category' && Name LIKE '%$search%' ORDER BY Name";
        } elseif ($sortvalue == 2) {
            $sql = "SELECT * from products WHERE Category='$category' && Name LIKE '%$search%' ORDER BY Price ASC";
        } else {
            $sql = "SELECT * from products WHERE Category='$category' && Name LIKE '%$search%' ORDER BY Price DESC";
        }
    }

    include 'connection.php';
    $qry = mysqli_query($connection, $sql);

    $count = mysqli_num_rows($qry);

    if ($count > 0) {
        echo "<table border=1>
                <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Category</th>
                    <th>Image</th>

                </tr>
            ";
        while ($row = mysqli_fetch_assoc($qry)) {
            $name = $row['Name'];
            $price = $row['Price'];
            $category = $row['Category'];
            $imageName = $row['ImageName'];

            echo "
                     <tr>
                         <td>$name</td>
                         <td>.£ $price</td>
                         <td>$category</td>
                         <td><img src='images/$imageName' /></td>
                     </tr>";
        }

        echo "</table>";

    } else {
        echo "No product Found";
    }

}
