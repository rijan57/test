<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
</head>

<body>

    <h1>Search</h1>

    <form action="search-product.php" method="GET">
        <select name="category" class="category">
            <option value="All">All</option>
            <option value="Phone" <?php if (isset($category)) {if ($category == "Phone") {echo "selected";}}?>>Phone
            </option>
            <option value="Bike" <?php if (isset($category)) {if ($category == "Bike") {echo "selected";}}?>>
                Bike</option>
            <option value="Car" <?php if (isset($category)) {if ($category == "Car") {echo "selected";}}?>>Car</option>
        </select>
        <input type="text" name="search-text" value="<?php if (isset($val)) {echo $val;}?>">

        <label>Sort By:</label>
        <select name="sort">
            <option value="1">Name</option>
            <option value="2">Price Ascending</option>
            <option value="3">Price Descending</option>
        </select>

        <input type="submit" name="search" value="Search"><br><br>
    </form>

</body>

</html>

<?php
include 'connection.php';
$sql = "SELECT * from products";

$qry = mysqli_query($connection, $sql);

$count = mysqli_num_rows($qry);

if ($count > 0) {
    echo "<table border=1>
                <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Category</th>
                    <th>Image</th>

                </tr>
            ";
    while ($row = mysqli_fetch_assoc($qry)) {
        $name = $row['Name'];
        $price = $row['Price'];
        $category = $row['Category'];
        $imageName = $row['ImageName'];

        echo "
                     <tr>
                         <td>$name</td>
                         <td>£ $price</td>
                         <td>$category</td>
                         <td><img src='images/$imageName' /></td>
                     </tr>";
    }

    echo "</table>";

}

?>
