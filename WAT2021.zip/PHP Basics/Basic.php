<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php

$name = "Rijan";
$studentId = "77263658";
echo "Name = " .$name;
echo "<br>Student Id= " .$studentId;
echo "<h3>My First PHP</h3>";

echo "<h2>Using Escape Characters</h2>";
echo '"most programmers say it’s better to use \'echo\'  rather than \'print\' ", says who?';

//Variables and Arithmetic Operators
echo "<h2>Variables</h2>";
$name="Rijan";
$age="20";
echo"Hi, My name is " .$name. " and I am " .$age. " years old.";

echo"<br>Hi, My name is $name and I am $age years old.";

//functions
echo "<h2>Functions</h2>";
//gettype()returns the type of a variable
echo gettype($name);
echo '<br />';
//strlen() returns the length of given string
echo strlen($name);
echo '<br />';
//strtoUpper()returns string converting into the Uppercase
echo strtoUpper($name);

//arithmetic
echo"<h2>Arithmetic</h2>";
$num1 = 9;
$num2 = 12;
echo "num1 x num2 = " .$num1 * $num2. "<br>";
echo "num1 as a percentage of num2 = " .$num1*100/$num2. "%" . "<br>";
echo "num2 divided by num1 = " .(int)($num2/$num1). "remainder". ($num2%$num1). "<br>";
echo"<h2>To Calculate Height in feet and inches</h2>";
echo"Name: " .$name. "<br>";
echo "Age: " .$age. "<br>";
$height = 1.8; //height in meters
$heightIninches= ($height*100)/2.54;
$heightInfeet=$heightIninches/12;
$feet=floor($heightInfeet);
echo "Height in Feet and inches:" . $feet. "ft" .($heightIninches%12). "inches</br>";
?>
</body>
</html>