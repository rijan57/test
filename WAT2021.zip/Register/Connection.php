<?php
$host="localhost";
$dname="wat2021";
$user="root";
$pass="";
$con = mysqli_connect($host,$user,$pass,$dname) or die("Unable to Connect To The Network");
?>