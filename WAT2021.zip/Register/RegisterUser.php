<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register_User</title>
</head>
<body>
    
    <?php
    $nameEmpty="";
    $passEmpty="";
    $emailEmpty="";
    $ageEmpty="";
    $TermEmpty="";
    $AllError="";
    $name="";
    $password="";
    $email="";
    $age="";

    if(isset($_POST['Register']))
    {
         
        $name=$_POST['Username'];
        $password=md5($_POST['password']);
        $email=$_POST['Email'];
        $age=$_POST['Age'];

        if((empty($name))&&(empty($_POST['password']) )||(empty($name))&&(empty($email))||(empty($_POST['password']) )&&(empty($email))){
            $AllError="Fill All The Required Field";
        }
 
        if(empty($name)){
            $nameEmpty="Enter Your Name";
             
        }
        else if(empty($_POST['password']) ){
            $passEmpty="Enter Your Password";
            $password="";
        }
        else if(empty($email)){
            $emailEmpty="Enter Your Email";
        }
        else if(empty($age)){
            $ageEmpty="Select Your Age"; 
        } 
        else if(!isset($_POST['TermAndCondition'])){
            $TermEmpty="Accept Term and Condition";
        }
        else{ 

            include("Connection.php");
            $sql="INSERT INTO users(Username,Password,Email,Age ) Values ('$name','$password','$email','$age')";
            $qry=mysqli_query($con,$sql) or die(mysqli_error($con));
            if($qry){
                echo "Data Inserted Successfully"; 
                $name="";
                $password="";
                $email="";
                $age="";
            } 
        }
    } 
    ?> 
     <span style="color:red"><?php echo $AllError?></span></br>
    <form action="" method="POST" enctype="multipart/form-data" >
        <fieldset> 
            <legend>Registration</legend> 
            <label for="Username">Username :</label> <span style="color:red"><?php echo $nameEmpty?></span></br>
            <input type="text" name="Username" value=<?php echo $name;?>></br>

            <label for="password">Password :</label> <span style="color:red"><?php echo $passEmpty?></span></br>
            <input type="password" name="password" value=<?php echo $password;?>></br>

            <label for="Email">Email :</label><span style="color:red"><?php echo $emailEmpty?></span></br>  
            <input type="Email" name="Email" value=<?php echo $email;?> ></br>

            <label for="Age">Age :</label><?php echo $ageEmpty?></br>
            <select name="Age" id="Age" value=<?php echo $age;?>>
                <option value="Under 18">Under 18</option>
                <option value="18-30">18-30</option>
                <option value="30-45">30-45</option>
                <option value="Above 45">Above 45</option>
            </select></br> 

            <input type="checkbox" Id="Terms" name="TermAndCondition" value="1">
            <label for="Terms">Terms And Condition.</label><span style="color:red"><?php echo $TermEmpty?></span></br><br>
            
            &nbsp;&nbsp;&nbsp;&nbsp; 
            <input type="submit" name="Register" Value="Submit"> 
        </fieldset>
    </form>
</body>
</html>