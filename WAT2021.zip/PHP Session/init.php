<?php 
//Set up the database access credentials
session_start();
$hostname = 'localhost'; 
$username = 'root'; 
$password = ''; 
$databaseName = 'wat2021';
$connection = mysqli_connect($hostname, $username, $password, $databaseName) or 
exit("Unable to connect to database!");
?>