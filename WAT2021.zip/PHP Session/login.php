<?php
include("init.php");
if(isset($_POST['subLogin'])){
    
$name=trim($_POST['txtUser']);
$pass=trim($_POST['txtPass']);

$sql="SELECT * FROM users where username='$name' and password= '$pass'";
$result=mysqli_query($connection,$sql) or die(mysqli_error($connection));

   if ($row = mysqli_fetch_assoc($result)) {
    $_SESSION['user']=$name;
    header ('location: sessions.php');
    } else {
    $_SESSION['error']= 'User not recognised';
    header ('location: sessions.php');
    }
}

?>