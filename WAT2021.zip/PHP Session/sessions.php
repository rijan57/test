<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session</title>
 
</head>
<body>
<?php
include('init.php');
if(isset($_SESSION['user'])){
    $username=$_SESSION['user'];
    echo "Welcome to our page ".$username."<br>";
    echo "<a href='protected.php'>protected</a><br>";
    echo "<a href='logout.php'>logout</a>";
}else{
    include("loginform.php");
   echo $_SESSION['error']= 'User not recognised';
}
?>
</body>
</html>