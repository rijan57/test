<?php
//error_reporting(0);
//to connect to mysql
//1. mysql
//2. mysqli
//3. PDO
$host = "localhost";
$dbname = "wat2021";
$dbuser="root";
$dbpass="";
//host, user, password, dbname
$con = mysqli_connect($host, $dbuser, $dbpass, $dbname) or die ("Unable to connect to database");

 ?>