<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display User </title>
     
</head>
<body>
    <?php
    $sql="SELECT * FROM Customer ORDER BY ID";
    include("connection.php");
    $query=mysqli_query($con,$sql) or die(mysqli_error($con)); 
    $count=mysqli_num_rows($query);
    if($count>=1){
        echo "There Are $count Records";
    
    ?>
    <h3><a href="mysql.php">Add Customer</a></h3>
    <table>
        <thead>
            <th>ID</th>
            <th>First Name</th>
            <th>Surname</th>
            <th>Password</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Age</th>
        </thead>
        <tbody>
            <?php
            while($row=mysqli_fetch_array($query))
            {
                echo "<tr>
                    <td> ".$row["ID"]."</td>\t
                    <td> ".$row["Fname"]."</td>
                    <td> ".$row["Sname"]."</td>
                    <td> ".$row["Password"]."</td>
                    <td> ".$row["Email"]."</td>
                    <td> ".$row["Gender"]."</td> 
                    <td> ".$row["Age"]."</td>
                </tr> 
                ";
            }
            ?>
        </tbody>
    </table>
<?php  
}
else{
    echo "No Record Found";
}
?>
</body> 
</html>

 