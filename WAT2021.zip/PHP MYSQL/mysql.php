<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
</head>
<body>
    

    <form method= "POST" action="insertRecord.php" enctype="multipart/form-data" name ="Registration">
        <fieldset>
            <legend>Enter Customer Details</legend>
            <label >First Name :</label>
            <input type="text" name="fname"><br/><br/>

            <label >Surname    :</label>
            <input type="text" name="sname"><br/><br/>

            <label >password   :</label>
            <input type="password" name="password"><br/><br/>
            
            <label >email      :</label>
            <input type="email" name="email"><br/><br/>
            
            <label >Gender     :</label>
            <select name="gender" id="Gender">
                <option value="1">Male</option>
                <option value="2">Female</option>
            </select> <br/><br/>

            <label >Age        :</label>
            <input type="text" name="age"><br/><br>
 
            <input type="submit" name="Register" Value="Register" ><br/>
        </fieldset>
    </form>
    <a href="selectRecord.php">Display User</a>
</body>
</html>