<?php

    if(isset($_POST['Register'])){
        $fname = $_POST['fname'];
        $sname = $_POST['sname'];
        $pass = $_POST['password'];
        $email= $_POST['email'];
        $Gender = $_POST['gender'];
        $Age=$_POST['age']; 
    }

    include("connection.php");
    $sql="INSERT INTO Customer(Fname,Sname,Password,Email,Gender,Age) VALUES
    ('$fname' ,'$sname' ,'$pass' ,'$email','$Gender','$Age')";

    $qry=mysqli_query($con,$sql) or die(mysqli_error($con));
    if($qry){
        echo "Record Inserted Successfully";
    }
    else{
        echo "Unable To Insert Query";
    }
    
?><a href="selectRecord.php">Show Customer List</a>