<br>
    <h1><b>Manage Product</b></h1>
<?php 
//Make connection to database
include('../PHP MYSQL/connection.php');
//create a query to select all records from products table
$sql = "SELECT * FROM Product"; 
//run query and store the result in a variable called $result
$result = mysqli_query($con,$sql);
//Use a while loop to iterate through your $result array and display 
//ProductName, ProductPrice, ProductImageName.
echo "<table border='1'>";
echo"<thead>
        <tr>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Image</th>
        <th>Amend</th>
        <th>Delete</th></tr>
    </thead>";
    
echo "<tbody>";
while ($row = mysqli_fetch_array($result))
{
    echo "<tr>
    <td> ".$row['PName']."</td>
    <td>".$row['PPrice']."</td>
    <td><img src='./Images/".$row['PFileName']."'></td>
    <td><a href=amendProduct.php?id=".$row['Id'].">Amend</a></td> 
    <td><a href=deleteProduct.php?id=".$row['Id'].">Delete</a></td> 
    </tr>
    ";
}
echo "</tbody></table>";
mysqli_close($con);

?>
<a href="CRUD.php">Add Product</a>