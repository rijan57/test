<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> 
    <br>
    <h1><b>Manage Product</b></h1>
      
    <form method= "POST" action="insertProduct.php" enctype="multipart/form-data" >
        <fieldset>
            <legend>Enter New Product Details</legend>
            <label >Product Name :</label><br/>
            <input type="text" name="Pname"><br/><br/>

            <label >Price   :</label><br/>
            <input type="text" name="Pprice"><br/><br/>

            <label >Image FileName :</label><br/>
            <input type="text" name="FileName"><br/><br/>  

            <input type="submit" name="Register" Value="Register" >&nbsp;&nbsp;&nbsp;&nbsp; 

            <input type="Reset" name="Clear" Value="Clear" ><br/>

        </fieldset>
    </form><br>
    <a href="displayProduct.php">Show Product List</a><br>
    
</body>
</html>