<?php

if(isset($_POST['Register'])){
    $pname=$_POST['Pname'];
    $pprice=$_POST['Pprice'];
    $pFileName=$_POST['FileName'];
}
if(empty($pname)||empty($pprice)||empty($pFileName)){ 
    header("Location: CRUD.php?msg=Enter Data Before Saving ");
}
else{
    include('../PHP MYSQL/connection.php');
    $sql="INSERT INTO PRODUCT(PName,PPrice,PFileName)VALUES('$pname','$pprice','$pFileName')";
    $qry=mysqli_query($con,$sql)or die(mysqli_error($con));
    if($qry){
        header("Location: displayProduct.php?msg=Data Inserted Successfuly");
    }  
}


?>