<?php
//Make connection to database
include('../PHP MYSQL/connection.php');
//Gather data sent from amendProducts.php page
if(isset($_POST['Register']))
{
$newid=$_POST['id'];
$newname=$_POST['name'];
$newprice=$_POST['price'];
$newimage=$_POST['image'];
//Produce an update query to update product record for the id provided
$sql="UPDATE product SET PName='$newname', PPrice='$newprice',PFileName='$newimage' WHERE  Id='$newid'";

//run query
$qry=mysqli_query($con,$sql); 
//Redirect to crud.php page
header( 'Location: CRUD.php?msg=Product Updated Successfully' ) ;
}
?>
<?php
//Make connection to database
include('../PHP MYSQL/connection.php');
//Gather id sent from crud.php page
$eid = $_GET['id'];
//Produce query to select the product record for the id provided
$sql = "SELECT * FROM product WHERE Id=$eid";
//run query and store result
$qry = mysqli_query($con,$sql) or die(mysqli_error($con));
//extract row from result using mysqli_fetch_assoc()and store $row
while ($row = mysqli_fetch_assoc($qry))
{
    $eid=$row['Id'];
    $ename=$row['PName'];
    $eprice=$row['PPrice'];
    $eimage=$row['PFileName'];
}
mysqli_close($con);
?>

