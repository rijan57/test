<?php
//Make connection to database
include('../PHP MYSQL/connection.php');
//Gather id from $_GET[]
if(isset($_GET['id'])){
    $deletid = trim($_GET['id']);
    //Construct DELETE query to remove record where WHERE id provided equals 
    $sql = "DELETE FROM product WHERE Id = $deletid";
    //run $query
    $qry = mysqli_query($con,$sql) or die(mysqli_error($con));
    // check to see if Query is Executed
    if ($qry){  
        header("Location: crud.php?msg=Product Deleted Successfully");
    }  
    else {
        // print error message
        echo "Error in query: $qry. " . mysqli_error($con);
        exit ;
    }
}

?>
