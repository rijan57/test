<!DOCTYPE html>
<html lang="en">
 <head>
 <title>Web Applications and Technologies</title> 
 <style>
     body{
        font-family: verdana, helvetica, arial, sans-serif;
        font-size: 1em;
     }
 </style>
 </head>
 <body>
 <header>
 <h1>Rijan Maharjan 77263658</h1> 
 </header>
 
 <section id="container">
 <h1>Fundamentals of PHP</h1>
 <?php
    echo "<h1>Selection</h1>";
    echo "<br>";
   // $day=date('l');
   $day="Tuesday";
    echo 'it\'s '.$day;
    echo "<br>";

    if ($day=="Wednesday"){
        echo 'It\'s midweek';
    }else{
        echo 'it\'s not midweek';
    }
    echo "<br>";
    echo date_default_timezone_get();
    // $hour=date('H');
    date_default_timezone_set("Asia/Kathmandu");
    echo "<br>";
    echo "The current time is ".date('G');
    echo "<br>";

    if (date('G')<12){
        echo "Good Morning its currently ".date('G A');
    }else if(date('G')<=18){
        echo "Good Afternoon its currently ".date('G A');
    }else{
        echo "Good Night its currently ".date('G A');
    }

    echo "<br>";

    $password="password";
    $username="username";

    if (strlen($password)>4 && strlen($password)<10){
        echo "Password length is valid";
    }else{
        echo "password length is invalid";
    }
    echo "<br>";
    if($password="password" && $username=="username"){
        echo "password valid";
    }else{
        echo "password invalid";
    }
    echo "<br>";
    //ticket price
     $age=20;
     $members=TRUE;
    function ticket_detail(){
        $age=20;
        $members=TRUE;
      
        echo "Initial Ticket Price: £25 <br>";
        echo "Age: ".$age."<br>";
        if($members==TRUE){
            echo "Member:Yes <br>";
        }else{
            echo "Member:No <br>";
        }
    }

    echo "<br>";
    if ($age<12){
        ticket_detail();
        if ($members==True){
            echo "<br>Final Ticket Price: ".$final_price = 25-(50/100)*25;
        }else{
        echo "<br>Final Ticket Price: ".$final_price = 25-((50+10)/100)*25;
        }
       }else if($age<18){
        ticket_detail();
        if ($members==True){
            echo "Final Ticket Price: ".$final_price =25-((25+10)/100)*25;
        }else{
        echo "Final Ticket Price: ".$final_price =25-(25/100)*25;
        }
    }else if($age>65){
        ticket_detail();
        if ($members==True){
            echo "Final Ticket Price: ".$final_price =25-((25+10)/100)*25;
        }else{
        echo "Final Ticket Price: ".$final_price =25-(25/100)*25;
        }
        
    }else{
        ticket_detail();
        if ($members==True){
            echo "Final Ticket Price: ".$final_price=25-(10/100)*25;
        }else{
        echo "Final Ticket Price: ".$final_price="£25";
        }
    }

    echo "<br>";
    echo "<h1>ARRAY</h1>";
    
    echo "<h1>Simple Array</h1>";

    $product=array("T-shirt","Cap","mug");
    print_r($product);
    echo "<br>";
    $product[1]="shirt";
    print_r($product);
    echo "<br>";
    $product[3]="skirt";
    print_r($product);
    echo "<br>";
    echo "The items at index[2] is: ".$product[2];
    echo "<br>";
    echo "The items at index[3] is: ".$product[3];

    echo "<h1>Associative arrays</h1>";

    $customer=array("custId"=>12,"CustName"=> "sarah","custAge"=>23,"custGender"=>"F");

    print_r($customer);
    echo "<br>";
    $customer +=['CustEmail'=>'sarah@gmail.com'];
    print_r($customer);
    echo "<br>";
    echo "items in my customer array";
    echo "<br>";

    echo "the item at index [CustName] is: ".$customer['CustName'];
    echo "<br>";
    echo "the item at index [CustEmail] is: ".$customer['CustEmail'];


    echo "<h1>Multi-dimensional Array</h1>";

    $Stock=array(
     "ID1"=>array(
        "description" => "T-shirt",
        "price" => 9.99,
        "Stock" => 100,
        "color"=> array("blue","green","red")
     ),
     "ID2"=>array(
        "description" => "cap",
        "price" => 4.99,
        "Stock" => 50,
        "color"=> array("blue","black","grey")
     ),
     "ID3"=>array(
        "description" => "mug",
        "price" => 6.99,
        "Stock" => 30,
        "color"=> array("Yellow","green","pink")
     ),

    );

    print_r ($Stock);
    echo "<br>";
    echo "<br>";
    echo "<br>";
    echo "This is my order: <br>";
    echo $Stock["ID1"]["color"][1] ." ". $Stock["ID1"]["description"];
    echo "<br>";
    echo "Price: £". $Stock["ID1"]["price"];

    echo "<br>";
    echo "<br>";
    echo $Stock["ID2"]["color"][2] ." ". $Stock["ID2"]["description"];
    echo "<br>";
    echo "Price: £". $Stock["ID2"]["price"];


   
?>

<?php
echo"<h1>LOOP</h1>";
echo "<h3>While loop</h3>";
$counter=1;
while($counter<6){
    echo "Count: ".$counter."</br>";
    $counter++;
}
//echo '</br>';
$shirtprice=9.99;
$counter=1;
echo "<table style='border:black; border-width:1px; border-style:solid;'>";
echo "<th style='border:black; border-width:1px; border-style:solid;'>Quantity</th>";
echo "<th style='border:black; border-width:1px; border-style:solid;'>Price</th>";
while ($counter <=10){
    $total=$counter*$shirtprice;
    echo '<tr><td style="border:black; border-width:1px; border-style:solid;">'.$counter.'</td> <td style="border:black; border-width:1px; border-style:solid;"> £'.$total.'</td></tr></br>';
    $counter++;
}
echo "</table>";


echo "<h3>For Loop</h3>";
$names=array("Aayush","Ashish","Alok","Utkrista","Sanjay");
 for ($i=0;$i<5;$i++){
     echo $names[$i].'</br>';
 }
 echo "<h3>foreach loops</h3>";
 $names=array(
     "peter"=>"c123456",
     "kat"=>"c654321",
     "Laura"=>"c987654",
     "ali"=>"c654987",
     "Popacatapetal"=>"c765984"
 );
 foreach($names as $n=>$v){
     echo "Name: ".$n." ID: ".$v."</br>";
 }

 $city=array('Peter'=>'LEEDS','Kat'=>'bradford','Laura'=>'wakeFIELD');

 print_r ($city);
echo "<br>";
 foreach($city as $c =>$v){
   $value= ucfirst(strtolower($v));
   
   echo "[".$c."]=>".$value." ";
 }



?>


<?php
echo "<h2>Some Usefull Functions.</h2>";

//$password=null;
//$password=' ';
//$password='pass';
//$password=1234567;
//$password=trim("pass123  ");
$password="password";
//$password=trim("<script>alert('You have been hacked')</script>");


//echo "Password is: ".htmlentities($password)."<br/>";
echo "Password is: ".($password)."<br/>";

if(isset($password) && !empty($password)){
   // echo "Password OK. <br>";
   if(strlen($password)>6 && strlen($password)<=8){
    //echo "Password OK. <br>";
    if(is_numeric($password)){
        echo "PASSWORD cannot be numeric";
    }else{
        echo "password ok <br>";
        echo "Envrypted password is: ". md5($password);
    }
   }else{
       echo "Your password should be between 6 and 8 character in length";
   }

}else{
    echo "Please enter a password <br>";
}
?>
 </section>
 <footer> 
 <small> <a href="../watIndex.html">Home</a></small>
 </footer>
 </body>
</html>
