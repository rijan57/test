<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
</head>
<body>
    <h1>Proocessing input from html form</h1>
    <h2>login form using get</h2>
    <form action="forms.php" method="POST">
        <fieldset>
            <legend>login</legend>
            <label for="email">Email:  </label>
            <input type="text" name="txtEmail" value="<?php
            if(isset($_POST['txtEmail'])){
            echo $_POST['txtEmail']; 
            }
            ?>" /><br /><br>
            <label for="passwd">Password: </label>
            <input type="password" name="txtPass" value="
            <?php
            if(isset($_POST['txtPass'])){
            echo $_POST['txtPass']; 
            }
            ?>" /><br /><br>
            <input type="submit" value="Submit" name="loginSubmit" />
            <input type="reset" value="Clear" />
        </fieldset>
    </form>

    <?php
    if(isset($_POST['loginSubmit'])){
        $email=$_POST['txtEmail'];
        $pass=$_POST['txtPass'];


        echo "Email: ".$email." Password: ".$pass."<br>";
    }else{
        Echo "ERROR";
    }
    ?>

    <form method="post" action="forms.php">
        <fieldset>
        <legend>Comments</legend>
        <label for="">Email: </label>
        <input type="text" name="cemail" value="<?php
                    if(isset($_POST['cemail'])){
                    echo $_POST['cemail']; 
                    }
                    ?>" /><br />
        <textarea rows="4" cols="50" name="ccmt" value="<?php
                    if(isset($_POST['ccmt'])){
                    echo $_POST['ccmt']; 
                    }
                    ?>" ></textarea><br />
        <label for="">Click to Confirm: </label>
        <input type="checkbox" name="check" value="agree"><br />
        <input type="submit" value="Submit" name="submitcmt"/>
        <input type="reset" value="Clear" />
        </fieldset>
        </form>
        <?php
        if (isset($_POST['check'])){
        $confirm='Agreed<br />';
        }else{
        $confirm='Not Agreed<br />';
        }


        if(isset($_POST['submitcmt'])){
            $email=$_POST['cemail'];
            $cbox=$_POST['ccmt'];

            if(!empty($email) && !empty($cbox)){
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "Email: ".$email."<br>";
                }else{
                    echo "Invalid email format";
                }
            echo "Comments: ".$cbox."<br>";
            echo "Confirm: ".$confirm."<br>";
            }else{
                echo "email must not be empty";
            }
        }else{
            echo "ERROR";
        }
        ?>


        <h1>Tax Calculator</h1>
     
        <form action="forms.php" method="post">
            <fieldset>
                <legend>without TAX calculator</legend>
                <label>After Tax calculator</label>
                <input type="text" name="taxPrice">
                <label>Tax Rate</label>
                <input type="text" name="taxRate">
                <input type="submit" value="submit" name="Submit">
                <input type="reset" value="Clear" name="clear">
            </fieldset>
        </form>
        <?php  
        if(isset($_POST['Submit'])){
            $afterprice=$_POST['taxPrice'];
            $taxrate=$_POST['taxRate'];
      

            if(!empty($afterprice) && !empty($taxrate)){

                if(is_numeric($afterprice)&& is_numeric($taxrate) ){
                if (preg_match('/^\d+(:?[.]\d{2})$/ ', $afterprice))
                {
                    if(filter_var($taxrate,FILTER_VALIDATE_INT)){
                
                    $beforeTaxPrice= (100*$afterprice)/(100+$taxrate);

                    echo "<h4>Price before tax is:  £".  $beforeTaxPrice." </h4";
                    }else{
                        echo "please enter a whole number for tax rate";
                    }
                 }else{
                    echo "please enter the price in the format 99.99";
                }
                }else{
                    
                    echo "please enter the value in numberic format";
                }
            }else{
                echo "all fields required";
            }

         
        }
         ?>

 
                
        <h1>Passing Data Appended to an URL</h1>
        <h2>Pick a category</h2>
        <a href="forms.php?dog=Films">Films</a>
        <a href="forms.php?dog=Books">Books</a>
        <a href="forms.php?dog=Music">Music</a>
        <br>

        <?php  
        if(isset($_GET['dog'])){
        $value=$_GET['dog'];
        echo "<h3>The category chosen is ".$value."</h3>";
        }
        ?>

        <h1>EXTENSION EXERSICE</h1>
   
</body>
</html>