<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Extension</title>
</head>
<body>
    <h1>Order Form</h1>
     <form action="" method="post" name="login">
    <fieldset>
    <legend>Enter your login details</legend>
    <label>User Name : </label>
    <input type="text" name="username">
    <label>Email : </label>
    <input type="email" name="email">
    </fieldset>

    <fieldset>
        <legend>Pizza Selection</legend>
        <label>Size: </label>
        <input type="radio" name="pizza" value="Small" checked>Small
        <input type="radio" name="pizza" value="Medium" >Medium
        <input type="radio" name="pizza" value="Large" >Large
        <br>
        <br>
        <label>Topping</label>
            <select name="topping" size=1>
                <option value="values" selected>Please select</option>
                <option value="Onion"  >Onion</option>
                <option value="Mushroom" >Mushroom</option>
                <option value="Extra Cheese" >Extra Cheese</option>
                <option value="Other" >Others</option>
            </select>
<br><br>
        <label>Extras: </label>
        <input type="checkbox" name="extra[]" value="Parmesan">Parmesan
        <input type="checkbox" name="extra[]" value="Olives">Olives
        <input type="checkbox" name="extra[]" value="Capers">Capers
         <br>
 
    </fieldset>
    <input type="submit" name="submit" value="Submit" />
    <input type="reset" name="clear" value="Clear" />

    </form>
    <?php

if(isset($_POST['submit'])){
    //capturing the user input
    $username=$_POST["username"];
    $email=$_POST["email"];
    $pizza=$_POST['pizza'];
    $topping=$_POST['topping'];
    $extra=$_POST['extra'];
    echo "<h2>Thank You for your order: </h2>";
    echo "Customer ID: ".$username ."<br>"; 
    echo "Email : ".$email."<br>";
    echo "your order: ".$pizza." ".$topping."<br>";
   // echo "topping selection ".$topping."<br>";
    echo "Extra Topping: ";
    foreach($extra as $e){
        echo $e." ";
    }
   


} 
    ?>
</body>
</html>