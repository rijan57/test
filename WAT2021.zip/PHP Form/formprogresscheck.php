<!DOCTYPE html> 
<html> 
<head> 
 <title>Progress Check 2</title> 
</head> 
<body> 
 <h1>Basic</h1>
 <?php
 //Declare two variables assign one your name and the other your id
 $name="Rijan";
 $id='77263658';
 //Echo out a statement below using concatenation
 echo "My name is ".$name." and my id is ".$id ;
 //My name is Paul and my id is c123456
 
 
 
 ?>
 <h1>Loops</h1>
 <?php
 //Declare an array to hold the name of 4 colours
 $color=array("Red","Green","Blue","Yellow");
 //Set up a while loop - don't forget the counter
$x=0;
 while($x<count($color)){
      echo $x." ".$color[$x]."<br>";
     $x++;
 }
 //Set the loop condition to loop for the length of the array
 //In the loop echo out the counter and a colour from the array
 //at the location pointed to by the counter
 //Don't forget to increment the counter
 //Output like below:
 //0 Blue
 //1 Yellow
 //2 Red
 //3 Black
 
 
 
 ?>
 
 <h1>Forms</h1>
 <form method="post" action="" enctype = "multipart/form-data"> 
 <p><label>Userid:</label></p> 
 <input type="text" name="txtUser" value="" /> 
 <p><label>Password:</label></p>
 <input type="text" name="txtPass" value="" />
 <p><input type="submit" value="Submit" name="subUser"/></p>
 </form> 
 <?php
 //complete the form method and the form object names
 //collect the data entered into the form and echo to screen
 //As an extra - block processing of form until submitted
 if(isset($_POST['subUser'])){
     $userid=$_POST['txtUser'];
     $password=$_POST['txtPass'];

     echo $userid."<br>";
     echo $password."<br>";

 }
 
 ?>
</body>
</html>